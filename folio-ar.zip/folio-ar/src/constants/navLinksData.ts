export const NAV_LINKS_DATA = [
   {
      label: 'من أنا',
      route: '/#about',
   },
   {
      label: 'السيرة الشخصية',
      route: '/#experience',
   },
   {
      label: 'أعمالي',
      route: '/#work',
   },
   {
      label: 'تواصل معي',
      route: '/#contact',
   },
]
